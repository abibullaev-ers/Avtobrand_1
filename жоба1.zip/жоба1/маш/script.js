function showAddCarModal() {
  document.getElementById('addCarModal').style.display = 'block';
}

function closeAddCarModal() {
  document.getElementById('addCarModal').style.display = 'none';
}

function addCar() {
  const name = document.getElementById('carName').value;
  const image = document.getElementById('carImage').value;
  const price = document.getElementById('carPrice').value;

  if (!name || !image || !price) {
    alert('Барлық өрістерді толтырыңыз!');
    return;
  }

  const carCard = document.createElement('div');
  carCard.className = 'car-card';
  carCard.innerHTML = `
    <img src="${image}" alt="${name}" />
    <div class="car-info">
      <h3>${name}</h3>
      <p>Бағасы: ${price} ₸/күн</p>
      <button>Жалға алу</button>
    </div>
  `;

  document.getElementById('carGrid').appendChild(carCard);
  closeAddCarModal();

  // Форманы тазалау
  document.getElementById('carName').value = '';
  document.getElementById('carImage').value = '';
  document.getElementById('carPrice').value = '';
}

 /*-------------------------------------------*/

function addCar() {
  const name = document.getElementById('carName').value;
  const image = document.getElementById('carImage').value;
  const price = document.getElementById('carPrice').value;

  if (!name || !image || !price) {
    alert('Барлық өрістерді толтырыңыз!');
    return;
  }

  const carCard = document.createElement('div');
  carCard.className = 'car-card';
  carCard.innerHTML = `
    <img src="${image}" alt="${name}" />
    <div class="car-info">
      <h3>${name}</h3>
      <p>Бағасы: ${price} ₸/күн</p>
      <div class="car-buttons">
        <button onclick="showRentalModal()" class="rent-btn"><i class="fas fa-car"></i> Жалға алу</button>
        <button onclick="this.closest('.car-card').remove()" class="delete-btn"><i class="fas fa-trash"></i></button>
      </div>
    </div>
  `;

  document.getElementById('carGrid').appendChild(carCard);
  closeAddCarModal();

  // Форманы тазалау
  document.getElementById('carName').value = '';
  document.getElementById('carImage').value = '';
  document.getElementById('carPrice').value = '';
}

function showRentalModal() {
  document.getElementById('rentalModal').style.display = 'block';
}

function closeRentalModal() {
  document.getElementById('rentalModal').style.display = 'none';
}

/*---------------------------------------------------------*/
